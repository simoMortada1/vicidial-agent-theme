# vici-agent-theme

This is a vicidial agent theme to apply new design to vicidial 

## How to setup 

Download with git 

cd to your vicidial root dir 

1. Git clone git@github.com:cesarvargas289/vici-agent-theme.git
2. Go to your browser vici-agent-theme/vicidial.php

### it's done enjoy!

### Login
![login](https://user-images.githubusercontent.com/37882019/38203874-47a3a3b8-3666-11e8-9e97-0fa068a02273.png)

#### Re-login

![relogin](https://user-images.githubusercontent.com/37882019/38203472-eea4acae-3664-11e8-914a-f9450e79a2de.png)

### Logged in
![menu](https://user-images.githubusercontent.com/37882019/38203471-ee903d46-3664-11e8-9d79-e35179b99b26.png)

### Transfer call

![transfer call](https://user-images.githubusercontent.com/37882019/38203473-eeb78a72-3664-11e8-97b6-13f3b5d4942f.png)

### Still working on it!!
